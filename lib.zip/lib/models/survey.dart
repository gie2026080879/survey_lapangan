class Survey {
  final int? id;
  final String namaSurveyor;
  final String judul;
  final String kategori;
  final String keterangan;
  final double latitude;
  final double longitude;
  final double akurasi;
  final String fotoPath;
  final DateTime createdAt;

  Survey({
    this.id,
    required this.namaSurveyor,
    required this.judul,
    required this.kategori,
    required this.keterangan,
    required this.latitude,
    required this.longitude,
    required this.akurasi,
    required this.fotoPath,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'nama_surveyor': namaSurveyor,
        'judul': judul,
        'kategori': kategori,
        'keterangan': keterangan,
        'latitude': latitude,
        'longitude': longitude,
        'akurasi': akurasi,
        'foto_path': fotoPath,
        'created_at': createdAt.toIso8601String(),
      };

  factory Survey.fromMap(Map<String, dynamic> map) => Survey(
        id: map['id'] as int?,
        namaSurveyor: map['nama_surveyor'] ?? '',
        judul: map['judul'] ?? '',
        kategori: map['kategori'] ?? '',
        keterangan: map['keterangan'] ?? '',
        latitude: (map['latitude'] ?? 0).toDouble(),
        longitude: (map['longitude'] ?? 0).toDouble(),
        akurasi: (map['akurasi'] ?? 0).toDouble(),
        fotoPath: map['foto_path'] ?? '',
        createdAt: DateTime.parse(map['created_at']),
      );
}
