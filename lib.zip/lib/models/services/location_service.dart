import 'dart:async';
import 'package:geolocator/geolocator.dart';

class LocationService {
  static Future<Position> ambilPosisiSaatIni() async {
    final servisAktif = await Geolocator.isLocationServiceEnabled();
    if (!servisAktif) {
      throw Exception('GPS/Lokasi HP belum aktif. Silakan aktifkan terlebih dahulu.');
    }

    LocationPermission izin = await Geolocator.checkPermission();
    if (izin == LocationPermission.denied) {
      izin = await Geolocator.requestPermission();
    }
    if (izin == LocationPermission.denied) {
      throw Exception('Izin lokasi ditolak. Aplikasi membutuhkan akses lokasi.');
    }
    if (izin == LocationPermission.deniedForever) {
      throw Exception('Izin lokasi diblokir permanen. Ubah di Pengaturan > Aplikasi > Izin.');
    }

    try {
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 30),
        ),
      );
    } on TimeoutException {
      throw Exception('Koordinat tidak ditemukan (timeout). Pindah ke area terbuka lalu coba lagi.');
    }
  }
}
