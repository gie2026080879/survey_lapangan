import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/survey.dart';

class DatabaseService {
  static Database? _database;

  static Future<Database> _getDatabase() async {
    if (_database != null) return _database!;
    final path = join(await getDatabasesPath(), 'survey_lapangan.db');
    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE survey(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_surveyor TEXT NOT NULL,
            judul TEXT NOT NULL,
            kategori TEXT NOT NULL,
            keterangan TEXT,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            akurasi REAL,
            foto_path TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _database!;
  }

  static Future<int> insert(Survey survey) async {
    final db = await _getDatabase();
    return db.insert('survey', survey.toMap());
  }

  static Future<List<Survey>> getAll() async {
    final db = await _getDatabase();
    final rows = await db.query('survey', orderBy: 'id DESC');
    return rows.map((e) => Survey.fromMap(e)).toList();
  }

  static Future<int> delete(int id) async {
    final db = await _getDatabase();
    return db.delete('survey', where: 'id = ?', whereArgs: [id]);
  }
}
