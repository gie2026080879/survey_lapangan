import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../models/survey.dart';
import '../services/database_service.dart';
import '../services/location_service.dart';

class FormSurveyScreen extends StatefulWidget {
  const FormSurveyScreen({super.key});

  @override
  State<FormSurveyScreen> createState() => _FormSurveyScreenState();
}

class _FormSurveyScreenState extends State<FormSurveyScreen> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _judulController = TextEditingController();
  final _ketController = TextEditingController();

  final List<String> _daftarKategori = [
    'Infrastruktur', 'Lingkungan', 'Sosial', 'Ekonomi', 'Keamanan', 'Lainnya',
  ];

  String? _kategori;
  File? _foto;
  Position? _posisi;
  bool _fotoLoading = false;
  bool _lokasiLoading = false;
  bool _simpanLoading = false;

  @override
  void initState() {
    super.initState();
    // Otomatis ambil koordinat begitu form dibuka
    WidgetsBinding.instance.addPostFrameCallback((_) => _ambilKoordinat());
  }

  @override
  void dispose() {
    _namaController.dispose();
    _judulController.dispose();
    _ketController.dispose();
    super.dispose();
  }

  Future<void> _ambilFoto({ImageSource source = ImageSource.camera}) async {
    setState(() => _fotoLoading = true);
    try {
      final XFile? hasil = await ImagePicker().pickImage(
        source: source,
        maxWidth: 1600,
        imageQuality: 85,
      );
      if (hasil != null) setState(() => _foto = File(hasil.path));
    } catch (e) {
      _snack('Gagal membuka kamera/galeri: $e');
    } finally {
      if (mounted) setState(() => _fotoLoading = false);
    }
  }

  Future<void> _ambilKoordinat() async {
    setState(() => _lokasiLoading = true);
    try {
      final posisi = await LocationService.ambilPosisiSaatIni();
      if (!mounted) return;
      setState(() => _posisi = posisi);
      _snack('Koordinat berhasil diambil ✓');
    } catch (e) {
      _snack(e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _lokasiLoading = false);
    }
  }

  Future<void> _simpan() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_foto == null) { _snack('Foto lokasi wajib diambil terlebih dahulu.'); return; }
    if (_posisi == null) { _snack('Koordinat wajib diambil terlebih dahulu.'); return; }

    setState(() => _simpanLoading = true);
    try {
      // Salin foto ke folder permanen aplikasi
      final dir = await getApplicationDocumentsDirectory();
      final namaFile = 'survey_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final filePermanen = await _foto!.copy('${dir.path}/$namaFile');

      final survey = Survey(
        namaSurveyor: _namaController.text.trim(),
        judul: _judulController.text.trim(),
        kategori: _kategori ?? 'Lainnya',
        keterangan: _ketController.text.trim(),
        latitude: _posisi!.latitude,
        longitude: _posisi!.longitude,
        akurasi: _posisi!.accuracy,
        fotoPath: filePermanen.path,
        createdAt: DateTime.now(),
      );

      await DatabaseService.insert(survey);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      _snack('Gagal menyimpan: $e');
    } finally {
      if (mounted) setState(() => _simpanLoading = false);
    }
  }

  void _snack(String pesan) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(pesan)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Entry Survey')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ===== FOTO =====
            Container(
              height: 220,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey[400]!),
              ),
              child: _foto == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.photo_camera, size: 48, color: Colors.grey[500]),
                        const SizedBox(height: 8),
                        Text('Belum ada foto lokasi', style: TextStyle(color: Colors.grey[600])),
                      ],
                    )
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(_foto!, fit: BoxFit.cover),
                    ),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: _fotoLoading ? null : () => _ambilFoto(),
              icon: _fotoLoading
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.camera_alt),
              label: Text(_fotoLoading ? 'Membuka kamera...' : (_foto == null ? 'Ambil Foto Lokasi' : 'Ganti Foto')),
            ),
            Center(
              child: TextButton.icon(
                onPressed: _fotoLoading ? null : () => _ambilFoto(source: ImageSource.gallery),
                icon: const Icon(Icons.photo_library, size: 18),
                label: const Text('Atau pilih dari galeri'),
              ),
            ),

            // ===== FORM DATA =====
            const SizedBox(height: 8),
            TextFormField(
              controller: _namaController,
              decoration: const InputDecoration(
                labelText: 'Nama Surveyor',
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Nama surveyor wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _judulController,
              decoration: const InputDecoration(
                labelText: 'Judul Survey',
                prefixIcon: Icon(Icons.title),
                border: OutlineInputBorder(),
              ),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Judul wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              // Jika Flutter versi lama error, ganti `initialValue` menjadi `value`
              initialValue: _kategori,
              decoration: const InputDecoration(
                labelText: 'Kategori Survey',
                prefixIcon: Icon(Icons.category),
                border: OutlineInputBorder(),
              ),
              items: _daftarKategori
                  .map((k) => DropdownMenuItem(value: k, child: Text(k)))
                  .toList(),
              onChanged: (v) => setState(() => _kategori = v),
              validator: (v) => v == null ? 'Pilih kategori survey' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _ketController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Keterangan / Catatan Lapangan',
                prefixIcon: Icon(Icons.notes),
                border: OutlineInputBorder(),
              ),
            ),

            // ===== KOORDINAT =====
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.teal[50],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.teal),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.my_location, color: Colors.teal),
                      SizedBox(width: 8),
                      Text('Koordinat Lokasi', style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (_posisi == null)
                    Text('Koordinat belum diambil.', style: TextStyle(color: Colors.grey[600]))
                  else
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Latitude  : ${_posisi!.latitude.toStringAsFixed(6)}',
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text('Longitude : ${_posisi!.longitude.toStringAsFixed(6)}',
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text('Akurasi   : ±${_posisi!.accuracy.toStringAsFixed(1)} meter',
                            style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                      ],
                    ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _lokasiLoading ? null : _ambilKoordinat,
                      icon: _lokasiLoading
                          ? const SizedBox(
                              width: 18, height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Icon(Icons.gps_fixed),
                      label: Text(_lokasiLoading
                          ? 'Mencari koordinat...'
                          : (_posisi == null ? 'Ambil Koordinat Saat Ini' : 'Perbarui Koordinat')),
                    ),
                  ),
                ],
              ),
            ),

            // ===== SIMPAN =====
            const SizedBox(height: 24),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: _simpanLoading ? null : _simpan,
                icon: _simpanLoading
                    ? const SizedBox(
                        width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.save),
                label: Text(_simpanLoading ? 'Menyimpan...' : 'Simpan Survey'),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
