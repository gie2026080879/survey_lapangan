import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/survey.dart';
import '../services/database_service.dart';
import 'detail_survey_screen.dart';
import 'form_survey_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Survey>> _dataSurvey;

  @override
  void initState() {
    super.initState();
    _muatUlang();
  }

  void _muatUlang() => setState(() => _dataSurvey = DatabaseService.getAll());

  Future<void> _tambahSurvey() async {
    final hasil = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const FormSurveyScreen()),
    );
    if (hasil == true) _muatUlang();
  }

  Future<void> _hapusSurvey(Survey survey) async {
    final konfirmasi = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Data?'),
        content: Text('Hapus survey "${survey.judul}" beserta fotonya?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (konfirmasi == true) {
      if (survey.fotoPath.isNotEmpty) {
        try { await File(survey.fotoPath).delete(); } catch (_) {}
      }
      await DatabaseService.delete(survey.id!);
      _muatUlang();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Survey Lapangan')),
      body: FutureBuilder<List<Survey>>(
        future: _dataSurvey,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final list = snapshot.data ?? [];
          if (list.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Belum ada data survey.\nTekan tombol "Survey Baru" untuk mulai.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: () async {
              _muatUlang();
              await _dataSurvey;
            },
            child: ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(12),
              itemCount: list.length,
              itemBuilder: (context, i) => _itemSurvey(list[i]),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _tambahSurvey,
        icon: const Icon(Icons.add_a_photo),
        label: const Text('Survey Baru'),
      ),
    );
  }

  Widget _itemSurvey(Survey s) {
    final file = File(s.fotoPath);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => DetailSurveyScreen(survey: s)),
          );
          _muatUlang();
        },
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: file.existsSync()
                    ? Image.file(file, width: 72, height: 72, fit: BoxFit.cover)
                    : Container(
                        width: 72, height: 72, color: Colors.grey[300],
                        child: const Icon(Icons.image_not_supported),
                      ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.judul, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(s.kategori, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                    const SizedBox(height: 2),
                    Text(
                      '${s.latitude.toStringAsFixed(6)}, ${s.longitude.toStringAsFixed(6)}',
                      style: const TextStyle(fontSize: 12),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      DateFormat('dd MMM yyyy HH:mm').format(s.createdAt),
                      style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.red),
                onPressed: () => _hapusSurvey(s),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
