import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart'; // untuk tipe XFile
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/survey.dart';

class DetailSurveyScreen extends StatelessWidget {
  final Survey survey;
  const DetailSurveyScreen({super.key, required this.survey});

  Future<void> _bukaMaps(BuildContext context) async {
    final url = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=${survey.latitude},${survey.longitude}');
    try {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak dapat membuka Google Maps')));
    }
  }

  Future<void> _salinKoordinat(BuildContext context) async {
    await Clipboard.setData(
        ClipboardData(text: '${survey.latitude}, ${survey.longitude}'));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Koordinat disalin ✓')));
  }

  Future<void> _kirim() async {
    final teks = StringBuffer()
      ..writeln('*DATA SURVEY LAPANGAN*')
      ..writeln('Judul      : ${survey.judul}')
      ..writeln('Surveyor   : ${survey.namaSurveyor}')
      ..writeln('Kategori   : ${survey.kategori}')
      ..writeln('Koordinat  : ${survey.latitude}, ${survey.longitude}')
      ..writeln('Waktu      : ${DateFormat('dd MMM yyyy HH:mm').format(survey.createdAt)}')
      ..writeln('Keterangan : ${survey.keterangan.isEmpty ? '-' : survey.keterangan}');

    await Share.shareXFiles(
      [XFile(survey.fotoPath)],
      text: teks.toString(),
      subject: survey.judul,
    );
  }

  @override
  Widget build(BuildContext context) {
    final file = File(survey.fotoPath);
    return Scaffold(
      appBar: AppBar(title: Text(survey.judul, overflow: TextOverflow.ellipsis)),
      body: ListView(
        children: [
          file.existsSync()
              ? Image.file(file, height: 260, fit: BoxFit.cover)
              : Container(height: 260, color: Colors.grey[300],
                  child: const Icon(Icons.image_not_supported, size: 64)),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _barisInfo('Surveyor', survey.namaSurveyor, Icons.person),
                _barisInfo('Kategori', survey.kategori, Icons.category),
                _barisInfo('Waktu Survey',
                    DateFormat('dd MMM yyyy, HH:mm').format(survey.createdAt),
                    Icons.access_time),
                _barisInfo('Keterangan',
                    survey.keterangan.isEmpty ? '-' : survey.keterangan, Icons.notes),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.teal[50],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.teal),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.location_on, color: Colors.teal),
                          SizedBox(width: 8),
                          Text('Titik Koordinat', style: TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${survey.latitude.toStringAsFixed(6)}, ${survey.longitude.toStringAsFixed(6)}',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      Text('Akurasi GPS: ±${survey.akurasi.toStringAsFixed(1)} meter',
                          style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () => _salinKoordinat(context),
                              icon: const Icon(Icons.copy, size: 18),
                              label: const Text('Salin'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () => _bukaMaps(context),
                              icon: const Icon(Icons.map, size: 18),
                              label: const Text('Google Maps'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton.icon(
                    onPressed: _kirim,
                    icon: const Icon(Icons.send),
                    label: const Text('Kirim / Bagikan (Foto + Data)'),
                  ),
                ),
                const SizedBox(height: 8),
                Center(
                  child: Text(
                    'Kirim via WhatsApp, email, atau aplikasi lainnya.',
                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _barisInfo(String label, String nilai, IconData ikon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(ikon, size: 20, color: Colors.teal),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                const SizedBox(height: 2),
                Text(nilai, style: const TextStyle(fontSize: 15)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
